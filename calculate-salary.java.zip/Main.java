class Employee{
    double managers=50000;
    double programmers=20000;
    double employees=10000;
    double  calculate(double s){
        return employees+s ;
    }
}
class Manager extends Employee{
    double calculate(double s){
        return super.managers+s;
    }
}
class Programmer extends Employee{
    double calculate(double s){
        return super.programmers+s;
    }
}
public class Main{
    public static void main(String[] args){
        Employee emp=new Employee();
        System.out.println(emp.calculate(1000));
        Manager man=new Manager();
        System.out.println(man.calculate(1000));
        Programmer pro=new Programmer();
        System.out.println(pro.calculate(1000));
    }
}
